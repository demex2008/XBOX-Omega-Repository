# script.module.clouddrive.common


## Usage

```xml
<requires>
    <import addon="script.module.clouddrive.common" />
</requires>
```

