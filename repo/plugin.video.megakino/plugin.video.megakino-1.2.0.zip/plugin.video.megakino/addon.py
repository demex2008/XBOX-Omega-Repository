#!/usr/bin/pyhton
# -*- coding: utf-8 -*-
import xbmc,xbmcplugin,xbmcaddon,xbmcgui,xbmcvfs,os,sys,urllib,json,re,resolveurl

__addon__ =  xbmcaddon.Addon()


__plugin_handle__ = int(sys.argv[1])
__base_url__ = __addon__.getSetting('url_eum').strip()

try:
    from urllib.parse import urlparse  # Python 3
except ImportError:
    from urlparse import urlparse  # Python 2

def __get_sys_version__():
	return sys.version_info.major

def __fix_encoding__(path):
	if __get_sys_version__() == 2:

		if sys.platform.startswith('win'):return path.decode('utf-8')
		else:return path.decode('utf-8').encode('ISO-8859-1')

	elif __get_sys_version__() == 3:return path


def __quote_plus__(s):
	if __get_sys_version__() == 2:return urllib.quote_plus(s)
	elif __get_sys_version__() == 3:return urllib.parse.quote_plus(s)
	
def __unquote_plus__(s):
	if __get_sys_version__() == 2:return urllib.unquote_plus(s)
	elif __get_sys_version__() == 3:return urllib.parse.unquote_plus(s)

__addon__ =  xbmcaddon.Addon()
__addon_id__ = __addon__.getAddonInfo('id')
__addon_version__ = __addon__.getAddonInfo('version')
__addon_path__ = __fix_encoding__(__addon__.getAddonInfo('path'))
__addon_icon__ = __fix_encoding__(__addon__.getAddonInfo('icon'))
__addon_fanart__ = __fix_encoding__(__addon__.getAddonInfo('fanart'))

def __get_test_viewer__(t='TEST_VIEWER',s=''):### Aaddon path test viewer ###
	xbmcgui.Dialog().textviewer(str(t),str(s))
	d = open(os.path.join(__addon_path__,str(t) + '.txt'),"w", encoding="utf-8")
	d.write(s)
	d.close()

sys.path.append(os.path.join(__addon_path__,'resources','lib'))
import requests,cfscraper


def __dialog_imput_alphanum__(heading='',defaultt='',autoclose=0):
	return __quote_plus__(xbmcgui.Dialog().input(heading=heading,defaultt=defaultt,type=xbmcgui.INPUT_ALPHANUM,option=xbmcgui.INPUT_ALPHANUM,autoclose=autoclose))

def __get_domain__(url):
    return urlparse(url).netloc

def __get_url_specific_security_headers__(url):### nur py3 ###

    if url:
    
        if '?' in url:url = url.split('?')[0]
        
        origin_url = urlparse(url).scheme + '://' + urlparse(url).netloc
        
        return {
            'Origin':origin_url,
            'Referer':url,
            'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36'} # https://deviceatlas.com/blog/list-of-user-agent-strings #
    else:return {}

def __get_cfscrape_sess__(url='',stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict={}):
	sess = requests.Session()
	cfs = cfscraper.create_scraper(sess=sess,delay=delay)
	return cfs.get(url,stream=stream,allow_redirects=allow_redirects,verify=verify,timeout=timeout,headers=headers_dict)

def __post_cfscrape_sess__(url='',data={},stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict={}):
	sess = requests.Session()
	cfs = cfscraper.create_scraper(sess=sess,delay=delay)
	return cfs.post(url,data=data,stream=stream,allow_redirects=allow_redirects,verify=verify,timeout=timeout,headers=headers_dict)
	
def __regex_search__(regex,content):
	return re.compile(regex,re.DOTALL).search(content)

def __regex_findall__(regex,content):
	return re.compile(regex,re.DOTALL).findall(content)

def __add_item__(url='',title='',image='',fanart='',info_labels_update={},params_update={},add_contextmenu =[],imode='',is_folder=True,is_playable=False):

	iparams = {'url':url,'title':title,'image':image,'fanart':fanart,'imode':imode}
	cparams = {'url':url,'title':title,'image':image,'fanart':fanart}
	iparams.update(params_update)
	cparams.update(params_update)

	info_labels = {'Title':title}
	info_labels.update(info_labels_update)

	listitem = xbmcgui.ListItem(label=title,path=url)
	listitem.setInfo(type='video',infoLabels=info_labels)
	listitem.setArt({'thumb':image,'poster':image,'banner':image,'fanart':fanart})

	if (is_folder == True and is_playable== False):
		url = sys.argv[0] + '?' + __quote_plus__(json.dumps(iparams))
		listitem.setProperty('IsPlayable','false')

	elif (is_folder == False and is_playable == False):
		url = sys.argv[0] + '?' + __quote_plus__(json.dumps(iparams))
		listitem.setProperty('IsPlayable','true')

	elif (is_folder == False and is_playable == True):
		listitem.setProperty('IsPlayable','true')

	com = []
	for title,cmode in add_contextmenu:
		if title and cmode:
			cparams.update({'cmode':cmode})
			com.append((title,'XBMC.RunPlugin('+ sys.argv[0] + '?' + __quote_plus__(json.dumps(cparams)) +')'))
	if com:listitem.addContextMenuItems(items=com,replaceItems=True)

	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=is_folder)

def __get_resolved_url__(url):
	try:
		source = resolveurl.HostedMediaFile(url=url)
		if source.valid_url():return source.resolve()
	except Exception as exc:xbmcgui.Dialog().notification('URL RESOLVER',str(exc),xbmcgui.NOTIFICATION_ERROR,2000,True);sys.exit(0)

def __set_resolved_url__(url=''):### is_folder = False and is_playable = False ###
	listitem = xbmcgui.ListItem(path=url)
	xbmcplugin.setResolvedUrl(handle=__plugin_handle__,succeeded=True,listitem=listitem)

def __get_entries_and_next_page__(url='',mode='get'):
    if mode =='get':req = __get_cfscrape_sess__(url=url,stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict=__get_url_specific_security_headers__(url))
    elif mode =='post':req = __post_cfscrape_sess__(url=url,data={},stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict=__get_url_specific_security_headers__(url))

    ###get_entries###
    for  url,img,title,xxx in __regex_findall__('<a\s+class=[^>]*href="([^"]+)">\s*<div\s+class="[^"]+">\s*<img\s+data-src="([^"]+)"\s+src="[^"]+"\s+alt="([^"]+)">\s*<div\s+class="poster__label">(.*?</div>)\s*</div>\s*</a>',req.text):
        __add_item__(url=url,title=title,image=__base_url__+ img,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='list_hosters',is_folder=True,is_playable=False)
	
    ###next_page_###   
    match = __regex_search__('">\s*<a\s+href="([^"]+)">\D',req.text)
    if match:
        __add_item__(url=match.group(1),title='Next >>',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='next',is_folder=True,is_playable=False)
	
    __end_of_directory__()
    
def __end_of_directory__():
	xbmcplugin.endOfDirectory(handle=__plugin_handle__,succeeded=True,updateListing=False,cacheToDisc=True)

def __get_params__():
	argv = __unquote_plus__(sys.argv[2][1:])
	if argv.startswith('{') and argv.endswith('}'):return json.loads(argv)
	else:return None
__params__ = __get_params__()

if __params__ is None:
    __add_item__(url=__base_url__,title='Neues',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='filme',is_folder=True,is_playable=False)
    __add_item__(url=__base_url__+'kinofilme/',title='[COLOR lime]Aktuelle Filme im Kino[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='filme',is_folder=True,is_playable=False)
    __add_item__(url=__base_url__+'films/',title='Filme',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='filme',is_folder=True,is_playable=False)
    __add_item__(url=__base_url__,title='Gerne',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={'dropdown_list':'Genre'},add_contextmenu =[['','']],imode='get_dropdown_list',is_folder=True,is_playable=False)
    __add_item__(url=__base_url__+'multfilm/',title='Animationsfilme',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='filme',is_folder=True,is_playable=False)
    __add_item__(url=__base_url__+'serials/',title='Serien',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='serien',is_folder=True,is_playable=False)
    __add_item__(url=__base_url__+'documentary/',title='Dokumentattionen',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='filme',is_folder=True,is_playable=False)
    __add_item__(url=__base_url__,title='[COLOR lime]Suche[/COLOR]',image=os.path.join(__addon_path__,'resources','search.png'),fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='suche',is_folder=True,is_playable=False)
    __end_of_directory__()
    
elif __params__.get('imode') in ['filme','','serien','next']:
    __get_entries_and_next_page__(__params__.get('url'))
    
elif __params__.get('imode') == 'get_dropdown_list':
	
    dropdown_list = __params__.get('dropdown_list')
	
    url = __params__.get('url')
    req = __get_cfscrape_sess__(url=url,stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict=__get_url_specific_security_headers__(url))
	
    match = __regex_search__('<div\s+class="side-block__title">Genres</div>(.*?)</ul>\s*</div>',req.text)
    if match:
        for url,title in __regex_findall__('href="([^"]+)">([^<]+)</a>',match.group(0)):
            __add_item__(url=url,title=title,image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='get_dropdown_select_url',is_folder=True,is_playable=False)
        __end_of_directory__()
	
elif __params__.get('imode') == 'get_dropdown_select_url':
	
	url = __params__.get('url')
	__get_entries_and_next_page__(url)
	
elif __params__.get('imode') == 'suche':
	text = __dialog_imput_alphanum__(heading='Suche ? Min 4 Zeichen !')
	__get_entries_and_next_page__('https://megakino.rip/index.php?do=search&subaction=search&search_start=0&full_search=0&result_from=1&story='+text,mode='post')
	
   
elif __params__.get('imode') == 'list_hosters':

    url = __params__.get('url')
    title = __params__.get('title')
    img = __params__.get('image')
    
    req = __get_cfscrape_sess__(url=url,stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict=__get_url_specific_security_headers__(url))
    if not '-staffel-' in url:
        
        ###movie_hoster### 
        for hoster_url in __regex_findall__('<iframe\s+id="film_main"\s+data-src="([^"]+)"',req.text):
            __add_item__(url=hoster_url,title=title+' | '+__get_domain__(hoster_url).upper(),image=img,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='play_hoster',is_folder=False,is_playable=False)
        
        ##movie_hoster_02###
        for hoster_url in __regex_findall__(r'<iframe\s+src=([^\s]+).*?width',req.text):
            __add_item__(url=hoster_url,title=title+' | '+__get_domain__(hoster_url).upper(),image=img,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='play_hoster_02',is_folder=False,is_playable=False)

    else:   ###liste_staffel###
        for ep,title in __regex_findall__('<option value="(ep.*?)">([^>]*?)<\/option>',req.text):
            match = __regex_search__('id="'+ep+'">([\s\S]*?)<\/select>',req.text)
            if match:
                __add_item__(url='',title=title.upper(),image=img,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={'hoster_content':match.group(1)},add_contextmenu =[['','']],imode='list_staffel_hosters',is_folder=True,is_playable=False)
    
    __end_of_directory__()

elif __params__.get('imode') == 'list_staffel_hosters':
    
    url   =   __params__.get('url')
    title =   __params__.get('title')
    img   =   __params__.get('image')

    hoster_content = __params__.get('hoster_content')

    ###staffel_hoster###
    for hoster_url,title in __regex_findall__('<option value="([^"]+)">([^>]*?)<\/option>',hoster_content):
        __add_item__(url=hoster_url,title=title+' | '+__get_domain__(hoster_url).upper(),image=img,fanart=__addon_fanart__,info_labels_update={'plot':'Plot?'},params_update={},add_contextmenu =[['','']],imode='play_hoster',is_folder=False,is_playable=False)
			
    __end_of_directory__()

elif __params__.get('imode') == 'play_hoster':

    hoster_url = __params__.get('url')
    play_url = __get_resolved_url__(hoster_url)
    __set_resolved_url__(url=play_url)
    
elif __params__.get('imode') == 'play_hoster_02':
    
    hoster_url = __params__.get('url')
    play_url = __get_resolved_url__(hoster_url)
    __set_resolved_url__(url=play_url)