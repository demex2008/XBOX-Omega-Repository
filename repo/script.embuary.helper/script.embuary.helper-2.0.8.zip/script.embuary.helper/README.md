## Embuary Helper Script

For more information please [visit the wiki](https://github.com/sualfred/script.embuary.helper/wiki)