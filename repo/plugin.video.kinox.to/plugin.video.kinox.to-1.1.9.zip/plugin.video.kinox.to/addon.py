#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcplugin,xbmcaddon
from contextlib import closing
import sys,os,urllib,re,time
import resolveurl

_addon_ =  xbmcaddon.Addon()

BASE_URL = _addon_.getSetting('url_eum').strip()
POST_URL = BASE_URL + '/aGET/List/'
HOSTER_URL = BASE_URL + '/aGET/Mirror/'
EPISODES_URL = BASE_URL + '/aGET/MirrorByEpisode/'

def get_norm_url(url):
	return url.replace('\/','/').replace('&amp;','&')

def __get_sys_version():
	return sys.version_info.major

def __fix_encoding__(path):
	if __get_sys_version() == 2:

		if sys.platform.startswith('win'):return path.decode('utf-8')
		else:return path.decode('utf-8').encode('ISO-8859-1')

	elif __get_sys_version() == 3:return path

def __quote_plus__(s):
	if __get_sys_version() == 2:return urllib.quote_plus(s)
	elif __get_sys_version() == 3:return urllib.parse.quote_plus(s)

def __unquote_plus__(s):
	if __get_sys_version() == 2:return urllib.unquote_plus(s)
	elif __get_sys_version() == 3:return urllib.parse.unquote_plus(s)

__player__ = xbmc.Player()
__addon__ =  xbmcaddon.Addon()
__addon_path__ = __fix_encoding__(__addon__.getAddonInfo('path'))

sys.path.append(os.path.join(__addon_path__,'resources','lib'))
import cfscraper

def get_fanart_image(fanart_image):
    return os.path.join(__addon_path__, 'resources', 'icons',fanart_image)

def get_color_text(color,text):
	return '[COLOR '+color+']'+text+'[/COLOR]'

def get_search_keyboard():
	return urllib.parse.quote(xbmcgui.Dialog().input(get_color_text('blue','Search ?'), type=xbmcgui.INPUT_ALPHANUM).strip())

def get_cf_url(url,stream=False,timeout=30,allow_redirects=False,scraper_delay=0,headers_dict={}):
	return get_cfscraper(url=url,delay=5,headers_dict=headers_dict)

def get_cfscraper(url='',stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict={}):
	with closing(cfscraper.create_scraper(delay=delay)) as scraper:
		return scraper.get(url,stream=stream,allow_redirects=allow_redirects,verify=verify,timeout=timeout,headers=headers_dict)

def post_cf_url(url,data,stream=False,timeout=30,allow_redirects=True,scraper_delay=3,headers_dict={}):
	return post_cfscraper(url=url,data=data,delay=5,headers_dict=headers_dict)

def post_cfscraper(url='',data={},stream=False,allow_redirects=False,verify=True,timeout=30,delay=5,headers_dict={}):
	with closing(cfscraper.create_scraper(delay=delay)) as scraper:
		return scraper.post(url,data=data,stream=stream,allow_redirects=allow_redirects,verify=verify,timeout=timeout,headers=headers_dict)

def add_items(items_array_dict=[['','','','',{},{}]], set_items_type_int=0, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False):

	item_type_dict ={0:'music',1:'video',2:'pictures',3:'game'}
	content_type_dict={0:'files',1:'songs',2:'artists',3:'albums',4:'movies',5:'tvshows',6:'episodes',7:'musicvideos',8:'videos',9:'images',10:'games'}

	xbmcplugin.setContent(int(sys.argv[1]),content_type_dict[set_content_type_int])

	for array_dict in items_array_dict:

		listitem=xbmcgui.ListItem(label=array_dict[0],path=array_dict[1])
		listitem.setArt({'thumb':get_fanart_image('icon.png'),'poster':array_dict[2],'banner':array_dict[2],'fanart':array_dict[2]})
		infolabels_dict={'Title':array_dict[0]}
		infolabels_dict.update(array_dict[4])

		params_dict={'Title':array_dict[0],'Url':array_dict[1],'Img':array_dict[2]}
		params_dict.update(array_dict[5])

		listitem.setInfo(type=item_type_dict[set_items_type_int],infoLabels=infolabels_dict)
		listitem.setProperty('fanart_image',get_fanart_image('fanart.jpg'))

		if(set_params_dict == True):url=sys.argv[0] +'?'+ __quote_plus__(str(params_dict))
		if(set_params_dict == False):url=array_dict[1]

		if(Is_playable_bool == True):listitem.setProperty('IsPlayable','true')
		if(Is_playable_bool == False):listitem.setProperty('IsPlayable','false')

		xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=is_folder_bool,totalItems=len(items_array_dict))

	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=True)

def get_regex_search(regex,content):
	return re.compile(regex,re.DOTALL).search(content)

def get_regex_findall(regex,content):
	return re.compile(regex,re.DOTALL).findall(content)

def get_resolved_url(url):
    try:
        source = resolveurl.HostedMediaFile(url=url)
        if source.valid_url():return source.resolve()
    except Exception as exc:xbmcgui.Dialog().notification('URL RESOLVER',str(exc),xbmcgui.NOTIFICATION_ERROR,2000,True);sys.exit(0)


def get_xbmc_player(title='',url='',img=''):

	listitem = xbmcgui.ListItem(label=title)
	listitem.setArt({'thumb':img,'poster':img,'banner':img,'fanart':img})
	listitem.setInfo(type='video',infoLabels={'Title':title})
	listitem.setProperty('IsPlayable','true')

	__player__.play(item=url,listitem=listitem)
	sys.exit(0)

def get_params_dict():
	argv = __unquote_plus__(sys.argv[2][1:])
	if argv.startswith('{') and argv.endswith('}'):return eval(argv)
	else:return {}
get_params_ = get_params_dict()

if get_params_ == {}:

	items_array_dict=[]
	items_array_dict.append(['[COLOR lime]Kinofilme[/COLOR]',BASE_URL + '/Kino-filme.html','','',{},{'Run':'1','Request':'get'}])
	items_array_dict.append(['Alle Filme',POST_URL + 'Page=1&Per_Page=10&url=/aGET/List/&dir=desc&sort=title&per_page=10&ListMode=cover&additional={"fType":"movie","Length":60,"fLetter":""}&iDisplayStart=0&iDisplayLength=10' ,'','',{},{'Run':'1','Ref':BASE_URL + '/Film-Movies.html','Request':'post'}])
	items_array_dict.append(['Beliebte Filme',BASE_URL + '/Popular-Movies.html','','',{},{'Run':'1','Request':'get'}])
	items_array_dict.append(['Neuste Filme',BASE_URL + '/Latest-Movies.html','','',{},{'Run':'1','Request':'get'}])

	items_array_dict.append(['Alle Serien',POST_URL + 'Page=1&Per_Page=10&url=/aGET/List/&dir=desc&sort=title&per_page=10&ListMode=cover&additional={"fType":"series","Length":60,"fLetter":""}&iDisplayStart=0&iDisplayLength=10' ,'','',{},{'Run':'1','Ref':BASE_URL + '/Film-Movies.html','Request':'post'}])
	items_array_dict.append(['Beliebte Serien',BASE_URL + '/Popular-TVSerien.html','','',{},{'Run':'1','Request':'get'}])
	items_array_dict.append(['Neuste Serien',BASE_URL + '/Latest-TVSerien.html','','',{},{'Run':'1','Request':'get'}])
	items_array_dict.append(['[COLOR lime]Suchen[/COLOR]',BASE_URL + '/Search.html?q=','','',{},{'Run':'1','Request':'get','Search':'search'}])

	add_items(items_array_dict, set_items_type_int=1, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False)

elif get_params_.get('Run') == '1':

	items_array_dict=[]
	url = get_params_.get('Url')
	ref = get_params_.get('Ref')
	req_type = get_params_.get('Request')

	if req_type == 'post':

		next_page_data = get_regex_search('\/Page=(\d+)&[\s\S]*?fType":"(.*?)"',url)

		data_dict={}
		for key,value in get_regex_findall('(\w+)\=(.+?)(?:&|$)',url):
			data_dict[key] = value

		content = post_cf_url(url,data=data_dict,headers_dict={'Origin':BASE_URL,'Referer':ref,'X-Requested-With':'XMLHttpRequest','Cookie':'ListMode=cover'}).text

		for title,url,img in get_regex_findall('<div class=."Opt leftOpt Headlne."><a title=."(.*?)." href=."(.*?)."[\s\S]*?src=."(.*?)."',content):
			items_array_dict.append([title,BASE_URL + get_norm_url(url),BASE_URL + img,'',{},{'Run':'3'}])

		if next_page_data:

			new_page_nr = str(int(next_page_data.group(1)) + 1)
			new_page_url = 'Page=%s&Per_Page=10&url=/aGET/List/&dir=desc&sort=title&per_page=10&ListMode=cover&additional={"fType":"%s","Length":60,"fLetter":""}&iDisplayStart=0&iDisplayLength=10' % (new_page_nr,next_page_data.group(2))

			color_text = get_color_text('lime','Next >>')
			items_array_dict.append([color_text,POST_URL + new_page_url,'','',{},{'Run':'1','Request':'post'}])

	elif req_type == 'get':

		if get_params_.get('Search')=='search':
			text = get_search_keyboard()
			if text:url = url + text
			else:sys.exit(0)

		content = get_cf_url(url,stream=False,timeout=30,allow_redirects=True,scraper_delay=0,headers_dict={'Origin':BASE_URL,'Referer':url,'X-Requested-With':'XMLHttpRequest','Cookie':'ListMode=cover'}).text
		for title,url,img in get_regex_findall('<div class="Opt leftOpt Headlne"><a title="(.*?)"\shref="(.*?)"[\s\S]*?src="(.*?)"',content):
			items_array_dict.append([title,BASE_URL + get_norm_url(url),BASE_URL + img,'',{},{'Run':'3'}])

	add_items(items_array_dict, set_items_type_int=1, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False)

elif get_params_.get('Run') == '2':

	url = get_params_.get('Url')
	content = get_cf_url(url,stream=False,timeout=30,allow_redirects=True,scraper_delay=0,headers_dict={'Origin':BASE_URL,'Referer':url,'X-Requested-With':'XMLHttpRequest','Cookie':'ListMode=cover'}).text

	items_array_dict=[]
	for title,url,img in get_regex_findall('<div class="Opt leftOpt Headlne"><a title="(.*?)"\shref="(.*?)"[\s\S]*?src="(.*?)"',content):
		items_array_dict.append([title,BASE_URL + get_norm_url(url),BASE_URL + img,'',{},{'Run':'3'}])

	add_items(items_array_dict, set_items_type_int=1, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False)

elif get_params_.get('Run') == '3':

	ftitle = get_params_.get('Title')
	url = get_params_.get('Url')
	img = get_params_.get('Img')

	items_array_dict=[]
	content = get_cf_url(url,stream=False,timeout=30,allow_redirects=True,scraper_delay=0,headers_dict={}).text

	episodes_data = get_regex_search('<select[\s\S]*?rel="(.*?)"[\s\S][^<]*(.*?[\s\S]*)<\/select>',content)
	if episodes_data:
		for value,data,title in get_regex_findall('<option value="(\d+)" rel="(.*?)"[\s\S]*?>(.*?)<\/option>',episodes_data.group(2)):
			for data in data.split(','):
				items_array_dict.append([title + ' Folge ' + data +' | '+ ftitle, EPISODES_URL + get_norm_url(episodes_data.group(1)) + '&Season=%s&Episode=%s' % (value,data),img,'',{},{'Run':'3'}])

	else:
		for url,title in get_regex_findall('class="MirBtn.*?rel="([^"]+)"[\s\S]*?class="Named">(.*?)<\/div>',content):
			items_array_dict.append([title+ ' | ' +ftitle,HOSTER_URL + get_norm_url(url),img,'',{},{'Run':'4'}])

	add_items(items_array_dict, set_items_type_int=1, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False)

elif get_params_.get('Run') == '4':
	title = get_params_.get('Title')
	url = get_params_.get('Url')
	img = get_params_.get('Img')

	content = get_cf_url(url,stream=False,timeout=30,allow_redirects=True,scraper_delay=0,headers_dict={}).text
	hoster_url = get_regex_search('Stream":"(?:<a href=\\\\"*|<iframe src=\\\\")(.*?)\\\\"',content)

	if hoster_url:
		hoster_url = get_norm_url(hoster_url.group(1))
		if not hoster_url.startswith('http'):hoster_url = 'http:' + hoster_url
		play_url = get_resolved_url(hoster_url)
		get_xbmc_player(title=title,url=play_url,img=img)